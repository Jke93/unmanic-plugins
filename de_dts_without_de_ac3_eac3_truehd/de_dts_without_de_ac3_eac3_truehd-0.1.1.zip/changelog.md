**<span style="color:#56adda">0.1.1</span>**
- plugin.py: fix typo in t.strip().lower()

**<span style="color:#56adda">0.1.0</span>**
- initial release